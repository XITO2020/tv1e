# FAQ tuveuxun.expert — Source de verite du bot Tv1E

Ce document est la **seule source autorisee** pour les reponses du bot.
Tout sujet hors de ce document → refus poli + redirection contact.

---

## TARIFS

### 3 forfaits packages
- **DIAGNOSTIC IA** : 690 € HT · 1 jour · demo d'un agent souverain live sur les donnees du client · deductible d'un forfait signe sous 30 jours
- **AGENT METIER** ⭐ best-seller : 1 900 € HT · 3 jours · agent metier (Claude, OpenClaw ou Mistral) + 1 skill pack + 30j support
- **AGENT SOUVERAIN SUR MESURE** : 3 900 € HT · 5 jours · voie adaptee (OpenClaw, Hermes ou Ollama) + Qwen3 sur le serveur du client, 2 skill packs, 60j support · pour mairies, juridique, sante · machine du client a part
- **JAMAIS D'ABONNEMENT** : mise a jour proposee tous les 4 mois a 120 €, refuser ne degrade rien

### Modules a la carte
- Skill pack metier additionnel (SKILL.md eprouve, teste, signe) : 290 €
- Mise a jour d'agent (tous les 4 mois, a l'acte) : 120 €
- Pipeline IA generative communication : 2 900 €
- Chatbot citoyen / adherent : 1 900 €
- Formation IA equipe (1 jour, jusqu'a 12 personnes) : 1 500 € / jour
- Direction artistique IA-augmentee : 900 € / jour (TJM)
- Refonte / dev plateforme web : 1 000 € / jour (TJM)
- Conseil strategique IA (RDV 2h) : 450 €

### Sur mesure
TJM 900 a 1 200 € HT / jour selon complexite. Devis ferme sous 48h apres RDV cadrage.

---

## DELAIS

| Prestation | Delai |
|---|---|
| Diagnostic IA | 1 jour |
| Agent metier | 3 jours |
| Agent souverain sur mesure | 5 jours |
| RDV decouverte | sous 48h |
| Devis ferme | sous 48h apres RDV |
| Formation 1 jour | a planifier |

---

## PROCESS

1. **RDV decouverte** 30 minutes gratuit (visio ou tel)
2. **Cadrage** : on definit ensemble le perimetre exact et les livrables
3. **Devis ferme** sous 48h
4. **Demarrage** apres acompte 30%
5. **Livraison** + 2h prise en main equipe
6. **Support** 30 ou 60 jours selon forfait

---

## EQUIPE

7 entites pluridisciplinaires :

- **Naïm** ⭐ intervenant principal · architecte agentique · full-stack senior · dev de ce site · fondateur QISHIM-CORTEX · formé par Orland Opal depuis 2010
- **Eddy** · agent organisationnel · consultant managing equipe · IA inter-teams · structure dediee
- **Manon** · lead full-stack · solutions financements et plateformes · structure dediee
- **Alex** · Growth Marketer · createur d'applications · structure dediee
- **June** · cybersecurite & pilote agents · experte Kali Linux
- **Orland Opal** · auteur · mentor de Naïmdepuis 2010, de June depuis 2017 · saga "Guerres Sources et Maudits"
- **QISHIM-CORTEX** · 12 cortex IA, 60 agents (Quantic Intelligence Structure with Hypervisor Intuition for Modelisation)

---

## CIBLES CLIENTS

- **PME / TPE** : automatiser taches repetitives (mails, docs, rapports)
- **Mairies / collectivites** : agent souverain on-premise · LLM local · RGPD blinde
- **Associations** : chatbot adherent · gestion subventions · com automatisee
- **Cabinets juridiques / sante** : LLM local · donnees jamais cloud
- **Pas de scale-ups Series A/B** : pas la cible

---

## STACK TECHNIQUE

### IA / Agents / LLM
Claude API · Hermas · Ollama · Llama 3 · Qwen · Mistral · Mixtral · MCP (Model Context Protocol) · ComfyUI · Hunyuan

### Frontend / Full-stack
React · Next.js 14 · Three.js · React Three Fiber · Prisma · Tailwind · Vue · Sass · ShadCN-UI 

### Backend / Infra
Python · FastAPI · Django · Node · Express · PostgreSQL · MongoDB · Docker · AWS · Linux · PHP8 · Symfony5 

### Direction artistique
Photoshop (20 ans) · Illustrator · Premiere (7 ans) · After Effects · Blender 3D · Audition · Davinci studio

---

## SOUVERAINETE / RGPD

Pour structures avec donnees sensibles (mairies, juridique, sante) :
- **Stack souveraine multi-voies** : selon la machine du client, on installe OpenClaw (plateforme d'agents accessible), Hermes (runtime open source MIT, Nous Research, auto-evolutif) ou un LLM local pur (Ollama + modele ouvert), avec Qwen3 / Mistral deployes sur VOTRE serveur. L'agent garde sa memoire chez vous, tourne en cron, repond par mail / Teams / WhatsApp / SMS
- **Aucune donnee n'envoie nulle part** : conformite RGPD maximale
- **Forfait Agent souverain sur mesure** : 3 900 € · 5 jours · 60j support · machine du client a part
- **Hardware audit gratuit** : 15 minutes pour evaluer ce que vous pouvez faire tourner

Documentation complete : /structure-souveraine

---

## SKILLS CLAUDE CODE

22 skills custom Claude Code developpes pour QISHIM-CORTEX et tuveuxun.expert.
**Publies gratuitement sur GitHub** sous license MIT (github.com/tabascocity).
Modele econo de Naïm: monetiser l'expertise humaine (consulting, formation, integration), pas vendre des fichiers.

Pour les developpeurs qui veulent apprendre :
- Pack onboarding Claude Code (1 demi-journee) : 480 €
- Coaching ad hoc : 120 € / heure
- Skill custom sur brief : a partir de 350 €
- Audit skills existants : 600 €

Catalogue + lien GitHub : /skills

---

## FORMATION

- **Bootcamp IA equipe** : 1 jour, jusqu'a 12 personnes, programme custom hands-on : 1 500 € / jour
- **Atelier dirigeants** : 1 demi-journee, cadrage strategique IA : 900 € / demi-journee
- **Coaching mensuel** : 1 jour/mois, suivi long terme : 1 500 € / jour
- **Pedigree** : 160 apprenants formes en 2 ans (bootcamp)

Detail : /tarifs#formation

---

## CONTACT

- **Localisation** : Ile-de-France · missions sur site et a distance
- **GitHub** : github.com/XITO2020 et github.com/tabascocity

---

## GARANTIES

- Forfait ferme · pas d'imprevus factures
- Devis sous 48h apres RDV cadrage
- Facture professionnelle · virement bancaire
- 1 cycle de retours inclus sur livrable
- RDV decouverte 30 min gratuit
- Confidentialite contractuelle

---

## INSTALLATION HERMES (souverain)

3 OS supportes, une journee sur place ou a distance :
- **Linux** (Ubuntu/Debian/Arch) : installeur de l'agent (OpenClaw/Hermes) en bash + Ollama + systemd
- **macOS** (Apple Silicon ou Intel) : installeur natif + Ollama + LaunchAgent
- **Windows** : installeur natif PowerShell, plus besoin de WSL2
- Contexte 64 000 tokens obligatoire pour l'usage avec outils (OLLAMA_CONTEXT_LENGTH=64000)

Modeles deployables selon hardware :
- 8 GB RAM CPU only → Phi-3 Mini 3.8B (POC, demo)
- 16 GB + GPU 8 GB VRAM → Qwen 2.5 7B (mairie, cabinet)
- 32 GB + RTX 3080/4080 → Llama 3 8B / Mixtral 8x7B (PME prod)
- 64 GB + RTX 4090 → Qwen 32B / Llama 70B Q4 (multi-utilisateurs)
